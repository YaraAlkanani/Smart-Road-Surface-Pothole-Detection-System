
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'dart:convert';

import 'package:smart_road/component/general_URL.dart';
import 'package:smart_road/view/profile_screen.dart';
import 'package:smart_road/view/user/mapsScreen.dart';




late String myname;
late String myphone;
late String myemail;

// ignore: camel_case_types
class Authentiction_Control {
  login(context, String email, String password,) async {
    var myUrl = Uri.parse("$serverUrl/login_client");
    print(email+password);
    print(myUrl);
    final response = await http.post(myUrl, body: {
      "email": "$email",
      "password": "$password",
    });
    print(response.body);
    print(response.statusCode);
    print(json.decode(response.body)['status']);
    if (json.decode(response.body)['status']=='1') {
        _save(json.decode(response.body)['data']['id'].toString());
        myname=json.decode(response.body)['data']['name'].toString();
        myphone=json.decode(response.body)['data']['phone'].toString();
        myemail=json.decode(response.body)['data']['email'].toString();
        Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) =>
                                 MapScreen()), (Route<dynamic> route) => false);
                              
    }
    else
      return AwesomeDialog(
        context: context,
        dialogType: DialogType.warning,
        animType: AnimType.bottomSlide,
        title: 'الحساب غير موجود',
        desc: json.decode(response.body)['error'].toString(),
        btnOkOnPress: () {},
      )..show();
  }





  Future register(
      String email, String password, String name,String phone,
       context) async {
        print(email);
        print(password);
        print(name);
        print(phone);
    var myUrl = Uri.parse("$serverUrl/register_client");
    print(myUrl);
    final response = await http.post(myUrl, body: {
      "email": email,
      "password": password,
      "name": name,
      'phone':phone,
    });
   
    print(response.body);
    print(response.statusCode);
    if (json.decode(response.body)['status']=="1") {
      AwesomeDialog(
        context: context,
        dialogType: DialogType.success,
        title: 'Done!',
        // btnOkOnPress: () {},
      ).show();
    } else {
      AwesomeDialog(
        context: context,
        dialogType: DialogType.error,
        animType: AnimType.bottomSlide,
        title: json.decode(response.body)['error'].toString(),
        // btnOkOnPress: () {},
      ).show();
    }
  }
  _save(String token) async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'token';
    final value = token;
    prefs.setString(key, value);
  }





  




}
