import 'package:flutter/material.dart';

var globalcolor= Color(0xfff2f2f2) ;//Color(0xffefdaa3)         //rgba(84,140,105,255)
var globalcolor2= Colors.purple;//rgba(254,233,178,255)\