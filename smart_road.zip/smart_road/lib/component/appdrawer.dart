
import 'package:flutter/material.dart';
import 'package:smart_road/authentication/login_screen.dart';
import 'package:smart_road/view/profile_screen.dart';
import 'package:smart_road/view/user/mapsScreen.dart';


class MyAppDrawer extends StatelessWidget {
  const MyAppDrawer({super.key});
  

  @override
  Widget build(BuildContext context) {
    var width= MediaQuery.of(context).size.width;
   var height= MediaQuery.of(context).size.height;
    return Drawer(
      backgroundColor: Colors.white,//rgba(192,189,174,255)
      child: Container(
        color: Colors.white,
        child: Column(
          children: [
           SizedBox(height: height/13,),
           Container(
            height: 100,
             child: SizedBox.fromSize(
               size: Size.fromRadius(100), // Image radius
               child: Image.asset("assets/logo.png"),
             ),
           ),
         
            SizedBox(height: height/80,),
            Container(
              width: width/1.5,
            height: height/15,
            alignment: Alignment.centerRight,
              child: InkWell(
                onTap: () {
                  Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) =>
                     MapScreen()), (Route<dynamic> route) => false);
                  
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Icon(Icons.home,color: Colors.blue,size: 30,),
                    Text("Home Page",style: TextStyle(color:Colors.black,fontSize: 12,fontWeight: FontWeight.bold),),
                  ],
                )
                ,
              ),
            ),
            SizedBox(height: height/80,),
            Container(
              width: width/1.5,
            height: height/15,
            alignment: Alignment.centerRight,
              child: InkWell(
                onTap: () {
                 Navigator.push(context,
                                      MaterialPageRoute(builder: (BuildContext context) {
                                    return ProfileScreen();
                                  }));  
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Icon(Icons.person,color: Colors.blue,size: 30,),
                    Text("Profile",style: TextStyle(color:Colors.black,fontSize: 12,fontWeight: FontWeight.bold),),
                  ],
                )
                ,
              ),
            ),
      
           SizedBox(height: height/80,),
      
      
            Container(
              width: width/1.5,
            height: height/15,
            alignment: Alignment.centerRight,
              child: InkWell(
                onTap: () {
                   Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) =>
                     LoginScreen()), (Route<dynamic> route) => false);
                  
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Icon(Icons.logout,color: Colors.blue,size: 30,),
                    Text("Log Out",style: TextStyle(color:Colors.black,fontSize: 12,fontWeight: FontWeight.bold),),
                  ],
                )
                ,
              ),
            ),
            
            
         
          ],
        ),
      ),
    );
  }
}