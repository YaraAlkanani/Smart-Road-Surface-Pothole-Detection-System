
String serverUrl = "https://std.scit.co/smart_road/public/api";

// String serverUrl ="http://"+ip+"/api";
String ip="192.168.1.3:80";
String imageUrl="https://std.scit.co/smart_road/storage/app/public/";