
import 'package:flutter/material.dart';
import 'package:smart_road/component/Color.dart';
Container textform(controllerText, String Title, TextInputType type,void Function()? onTappassword,bool _isHiddenPassword,String? Function(String?)? validator,Widget? prefixIcon) {
  
    return Container(
      height: 70,
      width: double.infinity,
      child: TextFormField(
        validator: validator,
        // textAlign: TextAlign.center,
        obscureText: type == TextInputType.visiblePassword
            ? _isHiddenPassword
            : false,
        keyboardType: type,
        cursorColor: Colors.black,
        controller: controllerText,
        decoration: InputDecoration(
          prefixIcon: prefixIcon,
          suffixIcon: type != TextInputType.visiblePassword
              ? SizedBox()
              : InkWell(
                  onTap:onTappassword,
                  child: Icon(
                    _isHiddenPassword
                        ? Icons.visibility_off
                        : Icons.visibility,
                    color: Colors.blue,
                  ),
                ),
          filled: true,
          fillColor: Colors.white,
          enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(15),
              borderSide: BorderSide(color: globalcolor2)),
          focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(3),
              borderSide: BorderSide(color: globalcolor2)),
          
          hintText: Title,
          hintStyle:
              TextStyle(color: Color(0xff8c9289), fontFamily: 'Cobe'),
        ),
      ),
    );
  }

  ElevatedButton loginbutton(String title, void Function()? onPressed) {
    return ElevatedButton(
        onPressed: onPressed,
        child: Text(
          title,
          style: TextStyle(
              fontSize: 20,
              color: Colors.white,
              fontWeight: FontWeight.bold),
        ),
        style: ElevatedButton.styleFrom(
            shape: RoundedRectangleBorder(
                // side: BorderSide(width: 1.0, color: Colors.black),
                borderRadius: BorderRadius.circular(10)),
            minimumSize: const Size(250, 50),
            backgroundColor:  globalcolor2));//0xff19892
  }