import 'package:flutter/material.dart';
import 'package:smart_road/authentication/login_screen.dart';

void main() async {
  runApp(const Test());
}

class Test extends StatefulWidget {
  const Test({Key? key}) : super(key: key);

  @override
  State<Test> createState() => _TestState();
}

class _TestState extends State<Test> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: LoginScreen(),
      theme: ThemeData(
        appBarTheme: AppBarTheme(
          color: Colors.blue, // يمكنك تغيير اللون الخلفي حسب الحاجة
          iconTheme: IconThemeData(color: Colors.white),
         titleTextStyle: TextStyle(color: Colors.white)
        ),
      ),
    );
  }
}
