import 'package:flutter/material.dart';
import 'package:http/http.dart' as http; // مكتبة http
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert'; // للتحويل بين JSON و Map

import 'package:smart_road/component/Color.dart';
import 'package:smart_road/component/general_URL.dart';
import 'package:smart_road/controller/authentication_controller.dart';
// تأكد من أن هذه المكتبة تحتوي على المتغير globalcolor

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  String name = myname;
  String phone = myphone;
  String email = myemail;
  bool isLoading = false; // حالة التحميل

  // تابع لتحديث البيانات مع الخادم
  Future<void> _updateProfile(String updatedName, String updatedPhone, String updatedEmail) async {
    setState(() {
      isLoading = true; // عرض حالة التحميل
    });
    final prefs = await SharedPreferences.getInstance();
  final clientId = prefs.getString('token');
    try {
      // طلب POST إلى الخادم
      final response = await http.post(
        Uri.parse('$serverUrl/update_client'),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'id': clientId, // تأكد أن client_id متوفر في المشروع
          'name': updatedName,
          'email': updatedEmail,
          'phone': updatedPhone,
        }),
      );

      if (response.statusCode == 200) {
        // في حال نجاح التحديث
        final responseData = jsonDecode(response.body);

        setState(() {
          // تحديث البيانات في الواجهة
          name = updatedName;
          phone = updatedPhone;
          email = updatedEmail;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Profile updated successfully!')),
        );
      } else {
        // عرض خطأ في حال الفشل
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to update profile.')),
        );
      }
    } catch (e) {
      // معالجة الأخطاء
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('An error occurred: $e')),
      );
    } finally {
      setState(() {
        isLoading = false; // إخفاء حالة التحميل
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: globalcolor2,
        title: Text("Profile"),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0), // إضافة تباعد حول المحتوى
        child: Card(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15.0), // جعل الحواف دائرية
          ),
          elevation: 5.0, // تأثير الظل
          child: Container(
            margin: EdgeInsets.all(20.0),
            child: Padding(
              padding: EdgeInsets.all(20.0), // تباعد داخل البطاقة
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildProfileRow('User Name:', name),
                  SizedBox(height: 20.0),
                  _buildProfileRow('Phone Number:', phone),
                  SizedBox(height: 20.0),
                  _buildProfileRow('Email:', email),
                  SizedBox(height: 20.0),

                  // زر تعديل الملف الشخصي
                  Center(
                    child: isLoading
                        ? CircularProgressIndicator() // عرض مؤشر التحميل
                        : ElevatedButton(
                            onPressed: () {
                              _showUpdateDialog(context); // فتح نافذة التحديث
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: globalcolor, // نفس اللون كما في الـ AppBar
                              padding: EdgeInsets.symmetric(horizontal: 50, vertical: 12),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30),
                              ),
                            ),
                            child: Text(
                              'Edit Profile', // دعم اللغات باستخدام GetX
                              style: TextStyle(fontSize: 16),
                            ),
                          ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildProfileRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label, // دعم اللغات باستخدام GetX
          style: TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold),
        ),
        Flexible(
          child: Text(
            value,
            style: TextStyle(fontSize: 18.0, color: Colors.grey[700]),
            textAlign: TextAlign.end,
          ),
        ),
      ],
    );
  }

  void _showUpdateDialog(BuildContext context) {
    TextEditingController nameController = TextEditingController(text: name);
    TextEditingController phoneController = TextEditingController(text: phone);
    TextEditingController emailController = TextEditingController(text: email);

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Update Profile'),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  controller: nameController,
                  decoration: InputDecoration(labelText: 'User Name'),
                ),
                TextField(
                  controller: phoneController,
                  decoration: InputDecoration(labelText: 'Phone Number'),
                  keyboardType: TextInputType.phone,
                ),
                TextField(
                  controller: emailController,
                  decoration: InputDecoration(labelText: 'Email'),
                  keyboardType: TextInputType.emailAddress,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                _updateProfile(
                  nameController.text,
                  phoneController.text,
                  emailController.text,
                );
              },
              child: Text('Save'),
            ),
          ],
        );
      },
    );
  }
}
