import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:smart_road/component/Color.dart';
import 'dart:async';
import 'package:smart_road/component/appdrawer.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:smart_road/component/general_URL.dart';

class MapScreen extends StatefulWidget {
  @override
  _MapScreenState createState() => _MapScreenState();
}

double lat = 0.0;
double lon = 0.0;

class _MapScreenState extends State<MapScreen> {
  Future<void> _updateCarLocation(double lat, double lon) async {
  final prefs = await SharedPreferences.getInstance();
  final clientId = prefs.getString('token'); // استرجاع client_id
  final carId = prefs.getString('car_id'); // استرجاع car_id (يفترض أن يكون قد تم تخزينه مسبقًا)
  print('hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh');
  if (clientId == null || carId == null) {
    print("Client ID or Car ID is missing");
    return;
  }

  final response = await http.post(
    Uri.parse('$serverUrl/update_car'),
    body: {
      'id': carId,
      'client_id': clientId,
      'lat': lat.toString(),
      'lon': lon.toString(),
    },
  );

  if (response.statusCode == 200) {
    final data = json.decode(response.body);
    if (data['status'] == "1") {
      print("Car location updated successfully.");
    } else {
      print("Failed to update location: ${data['message']}");
    }
  } else {
    print("Error updating car location: ${response.statusCode}");
  }
}

  late GoogleMapController mapController;
  StreamSubscription<Position>? positionStream;

  List<dynamic> potholes = []; // الحفر
  bool alertShown = false; // لمنع تكرار التنبيه

 @override
void initState() {
  super.initState();

  WidgetsBinding.instance.addPostFrameCallback((_) {
    _showWarningDialog();
  });

  // الحصول على الموقع الحالي
  _determinePosition().then((value) {
    setState(() {
      lat = value.latitude;
      lon = value.longitude;
      _goToTheNewPosition();
      _updateCarLocation(lat, lon); // إرسال الموقع لأول مرة
    });
  });

  // الاشتراك في تحديثات الموقع
  positionStream = Geolocator.getPositionStream(
    locationSettings: LocationSettings(
      accuracy: LocationAccuracy.high,
      distanceFilter: 10,
    ),
  ).listen((Position position) {
    setState(() {
      lat = position.latitude;
      lon = position.longitude;
      _goToTheNewPosition();
      _updateCarLocation(lat, lon); // إرسال الموقع عند كل تحديث
      _checkProximityToPotholes();
    });
  });

  // تحميل بيانات الحفر
  _loadPotholes();
}


  @override
  void dispose() {
    positionStream?.cancel();
    super.dispose();
  }

  // جلب بيانات الحفر
  Future<void> _loadPotholes() async {
    final response = await http.get(Uri.parse('$serverUrl/get_potholes'));
    print(response);
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      setState(() {
        potholes = data['data'];
      });
    } else {
      print('Error loading potholes');
    }
  }

  // التحقق من القرب من الحفر
  void _checkProximityToPotholes() {
    for (var pothole in potholes) {
      final distance = Geolocator.distanceBetween(
        lat,
        lon,
        pothole['lat'],
        pothole['lon'],
      );

      // إذا كانت المسافة أقل من 20 مترًا وأول مرة يظهر التنبيه
      if (distance < 20 && !alertShown) {
        alertShown = true;
        _showProximityAlert(pothole);
        break; // لا داعي لفحص باقي الحفر إذا تم العثور على واحدة قريبة
      }
    }
  }

  // عرض التنبيه عند الاقتراب من حفرة
  void _showProximityAlert(Map pothole) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          title: Row(
            children: [
              Icon(Icons.warning_amber_rounded, color: Colors.red, size: 40),
              SizedBox(width: 10),
              Text(
                'تحذير!',
                style: TextStyle(
                  color: Colors.red,
                  fontWeight: FontWeight.bold,
                  fontSize: 24,
                ),
              ),
            ],
          ),
          content: Text(
            'أنت تقترب من حفرة!\n'
            'الموقع: (${pothole['lat']}, ${pothole['lon']})',
            style: TextStyle(fontSize: 18, color: Colors.black87),
          ),
          backgroundColor: Colors.yellow[100],
          actions: [
            TextButton(
              style: TextButton.styleFrom(
                backgroundColor: Colors.red,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: Text(
                'موافق',
                style: TextStyle(color: Colors.white),
              ),
              onPressed: () {
                Navigator.of(context).pop();
                alertShown = false; // يسمح بعرض التنبيه مجددًا عند حفرة أخرى
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        drawer: MyAppDrawer(),
        appBar: AppBar(
          backgroundColor: globalcolor2,
          title: Text("Home Page"),
          bottom: TabBar(
            labelStyle: TextStyle(color: Colors.white),
            tabs: [
              Tab(icon: Icon(Icons.map,color: Colors.white,), text: "Potholes (Map)"),
              Tab(icon: Icon(Icons.list,color: Colors.white,), text: "Potholes (List)"),
              Tab(icon: Icon(Icons.car_rental,color: Colors.white,), text: "My Cars"),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _buildPotholesMapTab(),
            _buildPotholesListTab(),
            _buildCarsTab(),
          ],
        ),
      ),
    );
  }

  // التبويب الأول: عرض الحفر على الخريطة
  Widget _buildPotholesMapTab() {
    return GoogleMap(
      onMapCreated: (controller) {
        setState(() {
          mapController = controller;
        });
      },
      initialCameraPosition: CameraPosition(
        target: LatLng(lat, lon),
        zoom: 15.0,
      ),
      markers: potholes.map((pothole) {
        return Marker(
          markerId: MarkerId(pothole['id'].toString()),
          position: LatLng(pothole['lat'], pothole['lon']),
          infoWindow: InfoWindow(
            title: "Pothole ID: ${pothole['id']}",
            snippet: "Status: ${pothole['repair_status']}",
          ),
        );
      }).toSet(),
      myLocationEnabled: true,
    );
  }

  // التبويب الثاني: عرض الحفر بشكل قائمة
  Widget _buildPotholesListTab() {
    return ListView.builder(
      itemCount: potholes.length,
      itemBuilder: (context, index) {
        final pothole = potholes[index];
        return ListTile(
          leading: Icon(Icons.warning, color: Colors.red),
          title: Text("Pothole ID: ${pothole['id']}"),
          subtitle: Text(
            "Location: (${pothole['lat']}, ${pothole['lon']})\n"
            "Status: ${pothole['repair_status']}",
          ),
        );
      },
    );
  }

  // التبويب الثالث: عرض سيارات العميل
  Widget _buildCarsTab() {
  return FutureBuilder(
    future: _fetchMyCar(), // جلب بيانات السيارة
    builder: (BuildContext context, AsyncSnapshot<Map<String, dynamic>?> snapshot) {
      if (snapshot.connectionState == ConnectionState.waiting) {
        // أثناء التحميل
        return Center(child: CircularProgressIndicator());
      } else if (snapshot.hasError) {
        // في حال وجود خطأ
        return Center(child: Text("Error fetching cars"));
      } else if (!snapshot.hasData || snapshot.data == null) {
        // إذا لم تكن هناك سيارة، عرض نموذج الإضافة
        return _buildAddCarForm();
      } else {
        // إذا تم العثور على السيارة، عرض التفاصيل
        final car = snapshot.data!;
        return Card(
          margin: EdgeInsets.all(16),
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "Car Details",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 10),
                Text("Company: ${car['company']}"),
                Text("Model: ${car['model']}"),
                Text("Car Number: ${car['car_number']}"),
                Text("Client Name: ${car['client_name']}"),
                Text("Client Email: ${car['client_email']}"),
              ],
            ),
          ),
        );
      }
    },
  );
}

// دالة لجلب بيانات السيارة
Future<Map<String, dynamic>?> _fetchMyCar() async {
  final prefs = await SharedPreferences.getInstance();
  final clientId = prefs.getString('token'); // استرجاع client_id
  if (clientId == null) return null;

  final response = await http.post(
    Uri.parse('$serverUrl/get_client_car'),
    body: {'client_id': clientId},
  );

  if (response.statusCode == 200) {
    final data = json.decode(response.body);
    if (data['status'] == "1" && data['data'] != null) {
      final prefs = await SharedPreferences.getInstance();
      final key = 'car_id';
      final value = data['data']['id'].toString();
    prefs.setString(key, value);
      return data['data']; // إعادة بيانات السيارة
      
    }
  }
  return null; // لا توجد بيانات
}

// نموذج إضافة سيارة
Widget _buildAddCarForm() {
  final _formKey = GlobalKey<FormState>();
  String company = '';
  String model = '';
  String carNumber = '';

  return Padding(
    padding: EdgeInsets.all(16),
    child: Form(
      key: _formKey,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "Add a New Car",
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 20),
          TextFormField(
            decoration: InputDecoration(labelText: "Car Company"),
            validator: (value) =>
                value!.isEmpty ? "Please enter car company" : null,
            onSaved: (value) => company = value!,
          ),
          TextFormField(
            decoration: InputDecoration(labelText: "Car Model"),
            validator: (value) =>
                value!.isEmpty ? "Please enter car model" : null,
            onSaved: (value) => model = value!,
          ),
          TextFormField(
            decoration: InputDecoration(labelText: "Car Number"),
            validator: (value) =>
                value!.isEmpty ? "Please enter car number" : null,
            onSaved: (value) => carNumber = value!,
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                _formKey.currentState!.save();
                _addCar(company, model, carNumber); // إضافة السيارة
              }
            },
            child: Text("Add Car"),
          ),
        ],
      ),
    ),
  );
}

// دالة لإضافة سيارة جديدة
Future<void> _addCar(String company, String model, String carNumber) async {
  final prefs = await SharedPreferences.getInstance();
  final clientId = prefs.getString('token'); // استرجاع client_id
  if (clientId == null) return;

  final response = await http.post(
    Uri.parse('$serverUrl/add_car'),
    body: {
      'client_id': clientId,
      'company': company,
      'model': model,
      'lat': lat.toString(),
      'lon': lon.toString(),
      'car_number': carNumber,
    },
  );

  if (response.statusCode == 200) {
    final data = json.decode(response.body);
    if (data['status'] == "1") {
      setState(() {
        _fetchMyCar(); // إعادة جلب البيانات بعد الإضافة
      });
    } else {
      print('Failed to add car: ${data['message']}');
    }
  } else {
    print('Error adding car');
  }
}


  Future<Position> _determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return Future.error('Location services are disabled.');
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('Location permissions are denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return Future.error(
        'Location permissions are permanently denied, we cannot request permissions.');
    }

    return await Geolocator.getCurrentPosition();
  }

  Future<void> _goToTheNewPosition() async {
    final GoogleMapController controller = mapController;
    controller.animateCamera(CameraUpdate.newCameraPosition(
      CameraPosition(target: LatLng(lat, lon), zoom: 14.4746),
    ));
  }


  void _showWarningDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          title: Row(
            children: [
              Icon(Icons.warning_amber_rounded, color: Colors.red, size: 40),
              SizedBox(width: 10),
              Text(
                'تحذير',
                style: TextStyle(
                  color: Colors.red,
                  fontWeight: FontWeight.bold,
                  fontSize: 24,
                ),
              ),
            ],
          ),
          content: Text(
            'احذر! يوجد حفرة أمامك، يرجى اتخاذ الحذر.',
            style: TextStyle(fontSize: 18, color: Colors.black87),
          ),
          backgroundColor: Colors.yellow[100],
          actions: [
            TextButton(
              style: TextButton.styleFrom(
                backgroundColor: Colors.red,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: Text(
                'موافق',
                style: TextStyle(color: Colors.white),
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

}