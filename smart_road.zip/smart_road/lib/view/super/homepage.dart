import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:smart_road/component/Color.dart';
import 'dart:async';

import 'package:smart_road/component/appdrawer.dart';

class MapScreenSuper extends StatefulWidget {
  @override
  _MapScreenState createState() => _MapScreenState();
}

double lat = 0.0;
double lon = 0.0;

class _MapScreenState extends State<MapScreenSuper> with SingleTickerProviderStateMixin {
  late GoogleMapController mapController;
  StreamSubscription<Position>? positionStream;

  // قائمة من الحفر التي ستظهر على الخريطة
  Set<Marker> _potholes = {};
  late TabController _tabController;

  @override
  void initState() {
    super.initState();

    // بدء تتبع الموقع عند بداية التطبيق
    _determinePosition().then((value) {
      setState(() {
        lat = value.latitude;
        lon = value.longitude;
        _goToTheNewPosition();
      });
    });

    // الاشتراك في تغيير الموقع
    positionStream = Geolocator.getPositionStream(
      locationSettings: LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 10, // تحديث كلما تحرك المستخدم لمسافة 10 أمتار
      ),
    ).listen((Position position) {
      setState(() {
        lat = position.latitude;
        lon = position.longitude;
        _goToTheNewPosition();
      });
      print("Updated Location: lat = $lat, lon = $lon");
    });

    // إضافة بعض الحفر الافتراضية إلى الخريطة
    _addPotholes();

    // إعداد الـ TabController
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    positionStream?.cancel(); // إلغاء الاشتراك في حالة الخروج من الشاشة
    _tabController.dispose(); // التخلص من الـ TabController
    super.dispose();
  }

  // دالة لإضافة علامات الحفر على الخريطة
  void _addPotholes() {
    // يمكنك إضافة الحفر هنا بشكل يدوي أو عبر قاعدة بيانات
    setState(() {
      _potholes.addAll([
        Marker(
          markerId: MarkerId('pothole_1'),
          position: LatLng(24.7136, 46.6753), // موقع حفرة
          infoWindow: InfoWindow(
            title: 'حفرة بحاجة إلى إصلاح',
            snippet: 'اضغط للإصلاح أو الحذف',
            onTap: () {
              _showPotholeDialog('pothole_1');
            },
          ),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
        ),
        Marker(
          markerId: MarkerId('pothole_2'),
          position: LatLng(24.7185, 46.6820), // موقع حفرة أخرى
          infoWindow: InfoWindow(
            title: 'حفرة بحاجة إلى إصلاح',
            snippet: 'اضغط للإصلاح أو الحذف',
            onTap: () {
              _showPotholeDialog('pothole_2');
            },
          ),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
        ),
      ]);
    });
  }

  // دالة لحذف الحفرة عند الإصلاح
  void _removePothole(String markerId) {
    setState(() {
      _potholes.removeWhere((marker) => marker.markerId.value == markerId);
    });
  }

  // دالة لإظهار التنبيه عند الضغط على الحفرة
  void _showPotholeDialog(String markerId) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          title: Row(
            children: [
              Icon(Icons.build, color: Colors.orange, size: 40),
              SizedBox(width: 10),
              Text(
                'إصلاح الحفرة',
                style: TextStyle(
                  color: Colors.orange,
                  fontWeight: FontWeight.bold,
                  fontSize: 24,
                ),
              ),
            ],
          ),
          content: Text(
            'هل تم إصلاح هذه الحفرة؟',
            style: TextStyle(fontSize: 18, color: Colors.black87),
          ),
          actions: [
            TextButton(
              style: TextButton.styleFrom(
                backgroundColor: Colors.green,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: Text(
                'نعم، احذفها',
                style: TextStyle(color: Colors.white),
              ),
              onPressed: () {
                _removePothole(markerId); // حذف الحفرة
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              style: TextButton.styleFrom(
                backgroundColor: Colors.red,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: Text(
                'إلغاء',
                style: TextStyle(color: Colors.white),
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: MyAppDrawer(),
      appBar: AppBar(
        backgroundColor: globalcolor2,
        title: Text("خريطة الحفر"),
        bottom: TabBar(
          controller: _tabController,
          labelStyle: TextStyle(color: Colors.white),
          tabs: [
            Tab(text: "خريطة الحفر"),
            Tab(text: "قائمة الحفر"),
          ],
        ),
      ),
      backgroundColor: globalcolor,
      body: TabBarView(
        controller: _tabController,
        children: [
          // Tab 1: عرض الحفر على الخريطة
          GoogleMap(
            onMapCreated: (controller) {
              setState(() {
                mapController = controller;
              });
            },
            markers: _potholes, // عرض الحفر على الخريطة
            initialCameraPosition: CameraPosition(
              target: LatLng(lat, lon), // تحديد الموقع الابتدائي
              zoom: 15.0,
            ),
            myLocationEnabled: true,
            myLocationButtonEnabled: false,
            onCameraMove: (CameraPosition position) {},
          ),
          // Tab 2: عرض الحفر كـ List
          ListView.builder(
            itemCount: _potholes.length,
            itemBuilder: (context, index) {
              final marker = _potholes.elementAt(index);
              return ListTile(
                title: Text(marker.infoWindow.title ?? 'حفرة'),
                subtitle: Text(marker.infoWindow.snippet ?? 'لا توجد تفاصيل'),
                leading: Icon(Icons.location_on, color: Colors.red),
                onTap: () {
                  _showPotholeDialog(marker.markerId.value); // إظهار التنبيه
                },
              );
            },
          ),
        ],
      ),
    );
  }

  Future<Position> _determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return Future.error('Location services are disabled.');
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('Location permissions are denied');
      }
    }
    
    if (permission == LocationPermission.deniedForever) {
      return Future.error(
        'Location permissions are permanently denied, we cannot request permissions.');
    }

    return await Geolocator.getCurrentPosition();
  }

  Future<void> _goToTheNewPosition() async {
    final GoogleMapController controller = mapController;
    controller.animateCamera(CameraUpdate.newCameraPosition(
      CameraPosition(target: LatLng(lat, lon), zoom: 14.4746),
    ));
  }
}
