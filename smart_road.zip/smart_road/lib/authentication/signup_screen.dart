import 'package:flutter/material.dart';
import 'package:smart_road/authentication/helper.dart';
import 'package:smart_road/authentication/input_widgets.dart';
import 'package:smart_road/controller/authentication_controller.dart';


class SignUpScreen extends StatefulWidget {
  SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}
Authentiction_Control _authentiction_control=Authentiction_Control();
class _SignUpScreenState extends State<SignUpScreen> {
  //final _auth = AuthService();

  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passController = TextEditingController();
  final _phoneController = TextEditingController();

  final FocusNode _nameFocus = FocusNode();
  final FocusNode _emailFocus = FocusNode();
  final FocusNode _phoneFocus = FocusNode();
  final FocusNode _passwordFocus = FocusNode();
  bool _isLoading = false; // Loading state
  final _formKey = GlobalKey<FormState>();

// Create a variable to store the selected value
  String? _selectedGender;

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _passController.dispose();
    _nameFocus.dispose();
    _emailFocus.dispose();
    _passwordFocus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: true, // Adjust layout for keyboard
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Center(child: Text("New Account")),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Form(
            key: _formKey, // Assign the form key
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Image(
                  image: AssetImage("assets/logo.png"),
                  height: 250,
                  fit: BoxFit.contain,
                ),
                const SizedBox(
                  height: 20,
                ),
                CustomTextField(
                  hintText: "Full Name",
                  prefixIcon: Icons.person,
                  inputType: TextInputType.name,
                  controller: _nameController,
                  focusNode: _nameFocus,
                  onFieldSubmitted: (_) {
                    FocusScope.of(context).requestFocus(_emailFocus);
                  },
                  validator: Helper.validationName,
                ),
                
                const SizedBox(
                  height: 20,
                ),
                CustomTextField(
                  hintText: "Email",
                  prefixIcon: Icons.email,
                  inputType: TextInputType.emailAddress,
                  controller: _emailController,
                  focusNode: _emailFocus,
                  onFieldSubmitted: (_) {
                    FocusScope.of(context).requestFocus(_passwordFocus);
                  },
                  validator: Helper.validationEmail,
                ),
                const SizedBox(
                  height: 20,
                ),
                CustomTextField(
                  hintText: "Password",
                  obscureText: true,
                  inputType: TextInputType.text,
                  onFieldSubmitted: (_) {
                    FocusScope.of(context).requestFocus(_phoneFocus);
                  },
                  controller: _passController,
                  focusNode: _passwordFocus,
                  action: TextInputAction.done,
                  validator: Helper.validationPassword,
                ),
                const SizedBox(
                  height: 20,
                ),
                CustomTextField(
                  hintText: "Phone",
                  prefixIcon: Icons.phone,
                  inputType: TextInputType.phone,
                  controller: _phoneController,
                  focusNode: _phoneFocus,
                
                  validator: Helper.validationName,
                ),
                const SizedBox(height: 20),

                // Gender selection using Radio buttons
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Expanded(
                      child: ListTile(
                        title: const Text('Male'),
                        leading: Radio<String>(
                          value: 'Male',
                          groupValue: _selectedGender,
                          onChanged: (value) {
                            setState(() {
                              _selectedGender = value!;
                            });
                          },
                        ),
                      ),
                    ),
                    Expanded(
                      child: ListTile(
                        title: const Text('Female'),
                        leading: Radio<String>(
                          value: 'Female',
                          groupValue: _selectedGender,
                          onChanged: (value) {
                            setState(() {
                              _selectedGender = value!;
                            });
                          },
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 20),

                _isLoading
                    ? Center(
                        child: CircularProgressIndicator(
                        strokeWidth: 7.0,
                        color: Colors.teal,
                      ))
                    :
                    // Signup Button
                    SizedBox(
                        width: 200,
                        child: ElevatedButton(
                          onPressed: () {
                            // Handle create action
                            if (_formKey.currentState!.validate() &&
                                _selectedGender != null) {
                              _authentiction_control.register(_emailController.text, _passController.text , _nameController.text,_phoneController.text, context);
                            } else if (_selectedGender == null) {
                              // Show a gender selection error
                              setState(() {});
                            }
                          },
                          style: ButtonStyle(
                            backgroundColor:
                                MaterialStateProperty.all<Color>(Colors.blue),
                            textStyle: MaterialStateProperty.all<TextStyle>(
                              const TextStyle(fontSize: 16),
                            ),
                          ),
                          child: const Text(
                            'SignUp',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text("Already Have an account?"),
                    TextButton(
                      onPressed: () {
                        // Navigate to the login page
                        Navigator.pushNamed(context, 'login');
                      },
                      child: const Text(
                        "Login",
                        style: TextStyle(color: Colors.blue),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

// Future<void> signUp() async {
//   setState(() {
//     _isLoading = true; // Show loading indicator
//   });
//   final user = await _auth.createUserWithEmailAndPassword(
//       _emailController.text, _passController.text, context);
//   setState(() {
//     _isLoading = false; // Show loading indicator
//   });
//   if (user != null) {
//     await user.updateProfile(displayName: _nameController.text);
//     await _auth.signOut();
//
//     Navigator.pushNamed(context, 'login');
//   } else {
//     Helper.showMessage("فشل إنشاءالمستخدم", Colors.red, "#FF0000");
//   }
// }
}
