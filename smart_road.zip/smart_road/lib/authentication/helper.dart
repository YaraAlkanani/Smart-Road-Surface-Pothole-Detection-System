
//import 'package:fluttertoast/fluttertoast.dart';

class Helper {
  static String? validationPassword(value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your password';
    } else if (value.length < 8) {
      return 'Password length must be at least 8';
    }
    return null;
  }

  static String? validationEmail(value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your email';
    } else if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
      return 'Please enter a valid email';
    }
    return null;
  }

  static String? validationName(value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your full name';
    }
    return null;
  }

  static String? validationProfilePass(value) {
    if (value == null || value.isEmpty) {
      return null;
    } else if (value.length < 8) {
      return 'Password length must be at least 8';
    }
    return null;
  }

//   static void showMessage(String msgContent, Color colorBg, String webBg) {
//     Fluttertoast.showToast(
//         msg: msgContent,
//         toastLength: Toast.LENGTH_SHORT,
//         gravity: ToastGravity.SNACKBAR,
//         webPosition: "center",
//         timeInSecForIosWeb: 3,
//         backgroundColor: colorBg,
//         textColor: Colors.white,
//         webBgColor: webBg,
//         fontSize: 16.0);
//   }
//
// // Format date and time
//   static String formatDateTime(DateTime dateTime) {
//     return DateFormat('HH:mm  dd-MM-yyyy').format(dateTime);
//   }
//   static String formatDate(DateTime dateTime) {
//     return DateFormat('dd-MM-yyyy').format(dateTime);
//   }
}
